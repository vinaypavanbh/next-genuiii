package starter;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;

public class StepDefinitions {
    @Given("^I am thirsty$")
    public void i_am_thirsty() throws Throwable {
    }

    @When("^I order a cappuccino$")
    public void i_order_a_cappuccino() throws Throwable {
    }

    @Then("^I should not receive a latte$")
    public void i_should_not_receive_a_latte() throws Throwable {
    }

}
